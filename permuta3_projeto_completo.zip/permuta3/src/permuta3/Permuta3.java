
package permuta3;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.*;
import java.util.*;

@Entity
class Fornecedor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nome;

    public Fornecedor() {}
    public Fornecedor(String nome) {
        this.nome = nome;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String toString() { return id + ": " + nome; }
}

@Entity
class Produto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nome;

    @ManyToOne
    private Fornecedor fornecedor;

    public Produto() {}
    public Produto(String nome, Fornecedor fornecedor) {
        this.nome = nome;
        this.fornecedor = fornecedor;
    }
}

public class Permuta3 {
    private static final Scanner scanner = new Scanner(System.in);
    private static final SessionFactory sessionFactory = new Configuration()
            .configure("hibernate.cfg.xml")
            .addAnnotatedClass(Fornecedor.class)
            .addAnnotatedClass(Produto.class)
            .buildSessionFactory();

    public static void main(String[] args) {
        int opcao;
        do {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Cadastrar Fornecedor");
            System.out.println("2. Cadastrar Produto");
            System.out.println("0. Sair");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> cadastrarFornecedor();
                case 2 -> cadastrarProduto();
            }
        } while (opcao != 0);

        sessionFactory.close();
    }

    private static void cadastrarFornecedor() {
        System.out.print("Nome do fornecedor: ");
        String nome = scanner.nextLine();
        Fornecedor fornecedor = new Fornecedor(nome);

        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            session.persist(fornecedor);
            session.getTransaction().commit();
            System.out.println("Fornecedor cadastrado com sucesso!");
        }
    }

    private static void cadastrarProduto() {
        System.out.print("Nome do produto: ");
        String nome = scanner.nextLine();

        List<Fornecedor> fornecedores;
        try (Session session = sessionFactory.openSession()) {
            fornecedores = session.createQuery("from Fornecedor", Fornecedor.class).list();
        }

        if (fornecedores.isEmpty()) {
            System.out.println("Nenhum fornecedor encontrado. Cadastre um primeiro.");
            return;
        }

        System.out.println("Selecione o fornecedor:");
        for (int i = 0; i < fornecedores.size(); i++) {
            System.out.println(i + " - " + fornecedores.get(i).getNome());
        }
        int idx = scanner.nextInt();
        scanner.nextLine();

        Fornecedor fornecedorSelecionado = fornecedores.get(idx);
        Produto produto = new Produto(nome, fornecedorSelecionado);

        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            session.persist(produto);
            session.getTransaction().commit();
            System.out.println("Produto cadastrado com sucesso!");
        }
    }
}
